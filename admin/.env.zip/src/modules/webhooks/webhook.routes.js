const express = require('express');
const crypto = require('crypto');
const logger = require('../../utils/logger');

const router = express.Router();

// Meta Webhook Configuration
const WEBHOOK_VERIFY_TOKEN = process.env.META_WEBHOOK_VERIFY_TOKEN || 'buizz_webhook_token_2024';
const APP_SECRET = process.env.META_APP_SECRET;

/**
 * GET /api/webhooks/whatsapp
 * Meta will send a GET request to verify the webhook
 * Query params: hub.mode, hub.challenge, hub.verify_token
 */
router.get('/whatsapp', (req, res) => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];

  logger.info('Admin Webhook verification attempt', { mode, token: token ? 'present' : 'missing' });

  if (mode === 'subscribe' && token === WEBHOOK_VERIFY_TOKEN) {
    logger.info('Admin Webhook verified successfully');
    return res.status(200).send(challenge);
  }

  logger.warn('Admin Webhook verification failed', { mode, tokenReceived: token, tokenExpected: WEBHOOK_VERIFY_TOKEN });
  return res.status(403).json({ error: 'Forbidden' });
});

/**
 * POST /api/webhooks/whatsapp
 * Meta will send POST requests with webhook events
 * Payload can be up to 3 MB according to Meta documentation
 */
router.post('/whatsapp', (req, res) => {
  try {
    const body = req.body;

    // Verify webhook signature if APP_SECRET is configured
    if (APP_SECRET) {
      const signature = req.headers['x-hub-signature-256'];
      if (!signature) {
        logger.warn('Admin Webhook signature missing');
        return res.status(403).json({ error: 'Signature missing' });
      }

      const expectedSignature = 'sha256=' + crypto
        .createHmac('sha256', APP_SECRET)
        .update(JSON.stringify(body))
        .digest('hex');

      if (signature !== expectedSignature) {
        logger.warn('Admin Webhook signature verification failed');
        return res.status(403).json({ error: 'Invalid signature' });
      }
    }

    // Process the webhook event
    if (body.object === 'whatsapp_business_account') {
      logger.info('Admin WhatsApp webhook received', { entryCount: body.entry?.length });

      // Process each entry (Meta can send multiple entries in one webhook)
      body.entry?.forEach((entry) => {
        const changes = entry.changes || [];
        
        // Process each change in the entry
        changes.forEach((change) => {
          const field = change.field;
          const value = change.value;
          
          logger.info('Admin Webhook field received', { field, entryId: entry.id });

          // Handle different webhook fields according to Meta documentation
          switch (field) {
            case 'messages':
              handleMessagesWebhook(value);
              break;
            case 'message_template_status_update':
              handleTemplateStatusUpdate(value);
              break;
            case 'message_template_quality_update':
              handleTemplateQualityUpdate(value);
              break;
            case 'account_alerts':
              handleAccountAlerts(value);
              break;
            case 'phone_number_name_update':
              handlePhoneNumberNameUpdate(value);
              break;
            case 'phone_number_quality_update':
              handlePhoneNumberQualityUpdate(value);
              break;
            case 'business_capability_update':
              handleBusinessCapabilityUpdate(value);
              break;
            default:
              logger.info('Admin Unhandled webhook field', { field });
          }
        });
      });
    }

    // Always return 200 to acknowledge receipt (Meta retries on non-200)
    return res.status(200).json({ status: 'ok' });
  } catch (error) {
    logger.error('Admin Webhook processing error', { error: error.message, stack: error.stack });
    // Still return 200 to prevent Meta from retrying indefinitely
    return res.status(200).json({ status: 'error', error: error.message });
  }
});

/**
 * Handle messages webhook field
 * This includes both incoming messages and message status updates
 */
function handleMessagesWebhook(value) {
  try {
    const metadata = value.metadata;
    const messages = value.messages || [];
    const statuses = value.statuses || [];

    // Handle incoming messages
    messages.forEach((message) => {
      const from = message.from;
      const messageId = message.id;
      const timestamp = message.timestamp;
      const type = message.type;
      const contacts = value.contacts || [];

      logger.info('Admin Incoming WhatsApp message', {
        phone: metadata?.display_phone_number,
        phoneNumberId: metadata?.phone_number_id,
        from,
        messageId,
        type,
        timestamp,
        contactName: contacts[0]?.profile?.name,
      });

      // Handle different message types according to Meta documentation
      switch (type) {
        case 'text':
          const textBody = message.text?.body;
          logger.info('Admin Text message received', { from, textBody });
          // TODO: Implement admin-specific chatbot logic here
          break;
        case 'interactive':
          const interactiveType = message.interactive?.type;
          logger.info('Admin Interactive message received', { from, interactiveType });
          // TODO: Handle button/list responses
          break;
        case 'image':
          const imageId = message.image?.id;
          logger.info('Admin Image message received', { from, imageId });
          // TODO: Handle image messages
          break;
        case 'document':
          const documentId = message.document?.id;
          logger.info('Admin Document message received', { from, documentId });
          // TODO: Handle document messages
          break;
        case 'audio':
          const audioId = message.audio?.id;
          logger.info('Admin Audio message received', { from, audioId });
          break;
        case 'video':
          const videoId = message.video?.id;
          logger.info('Admin Video message received', { from, videoId });
          break;
        case 'location':
          const location = message.location;
          logger.info('Admin Location message received', { from, location });
          break;
        case 'contacts':
          const contactsData = message.contacts;
          logger.info('Admin Contacts message received', { from, contactsData });
          break;
        case 'reaction':
          const reaction = message.reaction;
          logger.info('Admin Reaction message received', { from, reaction });
          break;
        case 'order':
          const order = message.order;
          logger.info('Admin Order message received', { from, order });
          break;
        default:
          logger.info('Admin Unknown message type', { from, type });
      }
    });

    // Handle message status updates (sent, delivered, read, failed)
    statuses.forEach((status) => {
      const messageId = status.id;
      const statusType = status.status;
      const timestamp = status.timestamp;
      const recipientId = status.recipient_id;
      const errors = status.errors;

      logger.info('Admin Message status update', {
        messageId,
        status: statusType,
        timestamp,
        recipientId,
        errors,
      });

      // TODO: Update message status in database if tracking is needed
    });
  } catch (error) {
    logger.error('Admin Error handling messages webhook', { error: error.message });
  }
}

/**
 * Handle message template status updates
 */
function handleTemplateStatusUpdate(value) {
  try {
    logger.info('Admin Template status update received', {
      messageTemplateId: value.message_template_id,
      event: value.event,
      status: value.message_template_status,
    });
    // TODO: Update template status in database
  } catch (error) {
    logger.error('Admin Error handling template status update', { error: error.message });
  }
}

/**
 * Handle message template quality updates
 */
function handleTemplateQualityUpdate(value) {
  try {
    logger.info('Admin Template quality update received', {
      messageTemplateId: value.message_template_id,
      qualityScore: value.quality_score,
      category: value.category,
    });
    // TODO: Update template quality in database
  } catch (error) {
    logger.error('Admin Error handling template quality update', { error: error.message });
  }
}

/**
 * Handle account alerts
 */
function handleAccountAlerts(value) {
  try {
    logger.info('Admin Account alert received', {
      alertType: value.type,
      phoneNumberId: value.phone_number_id,
      alertDetails: value,
    });
    // TODO: Handle account alerts (messaging limits, business profile changes, etc.)
  } catch (error) {
    logger.error('Admin Error handling account alert', { error: error.message });
  }
}

/**
 * Handle phone number name updates
 */
function handlePhoneNumberNameUpdate(value) {
  try {
    logger.info('Admin Phone number name update received', {
      phoneNumberId: value.phone_number_id,
      verificationStatus: value.verification_status,
      requestReason: value.request_reason,
    });
    // TODO: Handle phone number name verification updates
  } catch (error) {
    logger.error('Admin Error handling phone number name update', { error: error.message });
  }
}

/**
 * Handle phone number quality updates
 */
function handlePhoneNumberQualityUpdate(value) {
  try {
    logger.info('Admin Phone number quality update received', {
      phoneNumberId: value.phone_number_id,
      qualityRating: value.quality_rating,
      previousQualityRating: value.previous_quality_rating,
    });
    // TODO: Handle phone number quality updates
  } catch (error) {
    logger.error('Admin Error handling phone number quality update', { error: error.message });
  }
}

/**
 * Handle business capability updates
 */
function handleBusinessCapabilityUpdate(value) {
  try {
    logger.info('Admin Business capability update received', {
      capability: value.capability,
      status: value.status,
      whatsappBusinessAccountId: value.whatsapp_business_account_id,
    });
    // TODO: Handle business capability updates (messaging limits, etc.)
  } catch (error) {
    logger.error('Admin Error handling business capability update', { error: error.message });
  }
}

module.exports = router;
